//
//  ViewController.swift
//  Photo App
//
//  Created by Spence on 7/27/18.
//  Copyright © 2018 Girls How Code. All rights reserved.
//

import UIKit

class ViewController: UIViewController,
    UINavigationControllerDelegate,
UIImagePickerControllerDelegate {
var TrashTracker=0
    
    
  //code to make Sodacan dissappear 
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        //this code is the segue from the camera to BubbleHomeViewController
        if segue.destination is BubbleHomeViewController
        {
            TrashTracker = TrashTracker+1
            let vc = segue.destination as? BubbleHomeViewController
            vc?.photoWasTaken = true
            vc?.TrashTracker=self.TrashTracker
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

