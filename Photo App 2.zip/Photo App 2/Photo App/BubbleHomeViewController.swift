//
//  BubbleHomeViewController.swift
//  Photo App
//
//  Created by Spence on 7/30/18.
//  Copyright © 2018 Girls How Code. All rights reserved.
//

import UIKit

class BubbleHomeViewController: UIViewController {
var photoWasTaken=false
    var TrashTracker = 0
    @IBOutlet weak var bubbles: UIImageView!
    @IBOutlet weak var SodaCan: UIImageView!
    
    @IBOutlet weak var CokeBottle: UIImageView!
    
    func stopAnimating(){
        
    }
    //code that makes sodacan go away
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        //this code is the segue from the camera to BubbleHomeViewController
        if segue.destination is
        ViewController
        {
            let vc = segue.destination as? ViewController
            vc?.TrashTracker=self.TrashTracker
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
    
        
        if photoWasTaken {
            
            if TrashTracker==1{
                SodaCan.isHidden=true
                print("sodacan")
            }
            else if TrashTracker == 0 {
                CokeBottle.isHidden=true
                print("trash")
                
            }
            
            photoWasTaken=false

        }// Do any additional setup after loading the view.
    }

    private func setUpImageViewAnimation(){
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
        }



    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */


